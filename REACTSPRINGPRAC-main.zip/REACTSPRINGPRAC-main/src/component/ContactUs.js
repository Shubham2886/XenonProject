import React, { useState } from 'react';

function ContactUsForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

    console.log(email);
    console.log(name);
    console.log(message);
  var m6 =(e)=>{
    //alert();
    fetch("http://localhost:8080/emp/saveContactus",{
        method: 'POST',
        headers:{
          'Content-Type': 'application/json'
        },
        body:JSON.stringify({
          name:name, email:email, message:message
        })
      })
      .then((response) => response.json())
      .then((data) => {
        console.log(data)
    
        
      })
      .catch(
        (e)=>{
          console.log(e);
        }
      )

  }

  function handleNameChange(event) {
    setName(event.target.value);
    console.log(event.target.value);
  }

  function handleEmailChange(event) {
    setEmail(event.target.value);
    console.log(event.target.value);
  }

  function handleMessageChange(event) {
    setMessage(event.target.value);
    console.log(event.target.value);
  }

  function handleSubmit(event) {
    event.preventDefault();
    console.log(`Name: ${name}\nEmail: ${email}\nMessage: ${message}`);
    // TODO: Send the form data to the server or perform some other action
  }

  return (
    <form onSubmit={handleSubmit}>
      <div class="container-fluid">
        <label htmlFor="name">Name:</label>
        <input type="text" id="name" value={name} class="form-control" onChange={handleNameChange} aria-label="Username" aria-describedby="addon-wrapping" />
      </div>
      <br/>
      <div>
        <label htmlFor="email">Email:</label>
        <input type="email" id="email" value={email} class="form-control" onChange={handleEmailChange} />
      </div>
      <div>
        <label htmlFor="message">Message:</label>
        <textarea id="message" value={message} class="form-control" onChange={handleMessageChange} aria-label="Username" aria-describedby="addon-wrapping"/>
      </div>
      <button type="submit" onClick={m6} class="btn btn-info">Submit</button>
    </form>
  );
}

export default ContactUsForm;
